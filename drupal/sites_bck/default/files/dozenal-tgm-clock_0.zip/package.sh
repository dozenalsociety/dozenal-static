#!/bin/bash
#+AMDG

zip -r dozenal-tgm-clock.zip ./;
